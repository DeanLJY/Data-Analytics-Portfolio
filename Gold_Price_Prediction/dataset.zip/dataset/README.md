# Gold Price Dataset

Welcome to the Gold Price data section of this project. This directory houses data that tracks the daily prices of gold. The data is crucial for our analysis and offers insights into the trends and fluctuations in gold prices over time.

## Data Source

The original dataset was obtained as an Excel (.xlsx) file from the Goldhub website, a renowned authority and source of comprehensive gold price data. You can access the original data [here](https://www.gold.org/goldhub/data/gold-prices).

## Data Extraction

The data was extracted from the "Daily" tab, which provides gold prices on a day-to-day basis. This granularity is suitable for our analysis, enabling us to understand and predict short-term fluctuations in gold prices.

## Data Format

For ease of use and compatibility, the extracted data has been saved as a .csv file. This format allows for simple data manipulation and analysis across various programming languages and platforms.

